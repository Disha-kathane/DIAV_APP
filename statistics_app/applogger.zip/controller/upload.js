const dbpool = require('../db/wabot');
const csvtojson = require('csvtojson');

module.exports = async (req, res) => {
    try {
        const result = await csvtojson().fromFile(req.files.sheet[0].path);
        const rows = Object.keys(result[0]).map(item => '`'+item+'`');
        let query = 'INSERT INTO `ezb_send_messages` ('+rows.join(', ')+', `flag`) VALUES ';

        result.forEach((item, index) => {
            let flag = 0;
            item.to = `'`+item.to+`'`;
            item.type = `'`+item.type+`'`;
            item.templateid = `'`+item.templateid+`'`;
            item.placeholders = `'`+item.placeholders+`'`;
            item.flag = `'`+flag+`'`;

            query += `(${Object.values(item).join(', ')})`
            query += (result.length <= (index + 1)) ? `;`: `, `
        });

        const queryResult = await dbpool.query(query);
    } catch (error) {
        console.log('Error in csv/xlsx');
    }
    return 'This is upload controller';
}