module.exports = async (req, res) => {
    try {
        res.send("i m in DBStats Page");
    } catch (error) {
        console.log(error);
        errorLogger.error(JSON.stringify(error));
        return error;
    }
}