const whatsappService = require('../services/whatsapp');
const userService = require('../services/users');
var appLoggers = require('../applogger.js');
var errorLogger = appLoggers.errorLogger;

module.exports = async (req, res) => {
    try {
        const access_token = 'EAAF2dj6y8d8BAPZCbF9ShPsrKbDdLv80NusyGrgGatlcmhy2fWYXxwA3Rql2F4l2aQX470ZAIfWlwG4Kgl8Aaf4yYMyXzMZAkHeRXrIBa8Oc6KU2DZBFFmVVb8IcMEfsma7hAzdi6ZA5nyGyCGeKkaLNk5bJLrNBB9mH7MpNSOZBVmp8RYPVV9L5rGZCdTxANsKfq4R68OvmGXZCVQcggt1HlBJeuAzhD4MZD';
        const instanceUrl = 'https://graph.facebook.com/';
        const mediaToken = await whatsappService.getUploadTokenAndSignature(instanceUrl, access_token);   
        const uploadResonse = await whatsappService.whatsappMediaUpload(instanceUrl, access_token, mediaToken.id);
        const result = await whatsappService.messageTemplate([{
                "type":"BODY",
                "text":"message-text"
            }, {
                "type":"HEADER",
                "format":"IMAGE",
                "example": {
                    "header_handle": [uploadResonse.h]
                }
            }], access_token);
            
        return result;
       
    } catch (error) {
        console.log(error);
        errorLogger.error(JSON.stringify(error));
        return error;
    }
}

