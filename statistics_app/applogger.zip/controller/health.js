const whatsappService = require('../services/whatsapp');
const userService = require('../services/users');
var appLoggers = require('../applogger.js');
var errorLogger = appLoggers.errorLogger;

module.exports = async (req, res) => {
    try {       
        if (!req.headers.apikey) {
            return {
                code: 403,
                status: 'FAILED',
                message: 'API Key is required',
                data: {}
            };
        }
        const apiKey = req.headers.apikey;
        const userId = await userService.getUserId(apiKey);

        if (!userId) {
            return {
                code: 400,
                status: 'FAILED',
                message: 'Correct API Key is required',
                data: {}
            };
        }

        const { waurl, authtoken } = await userService.getUserSettings(userId);  
        const waGetHealthStatus = await whatsappService.getHealth(authtoken, waurl);
        
        if (waGetHealthStatus == 'connected'){
            updatewaGetHealthStatus = '1';
        }else if(waGetHealthStatus == 'connecting'){
            updatewaGetHealthStatus = '2';
        }else if (waGetHealthStatus == 'disconnected'){
            updatewaGetHealthStatus = '3';
        }else if(waGetHealthStatus == 'uninitialized'){
            updatewaGetHealthStatus ='4';
        }else{
            updatewaGetHealthStatus ='5';
        }  

        userService.getWaHealthStatus(userId,updatewaGetHealthStatus);
        return({
            code: 200,
            status: 'SUCCESS',
        });

    } catch (error) {
        console.log(error);
        errorLogger.error(JSON.stringify(error));
        return error;
    }
}