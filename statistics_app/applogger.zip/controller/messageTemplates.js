const whatsappService = require('../services/whatsapp');
const templateService = require('../services/template')
const userService = require('../services/users');
var appLoggers = require('../applogger.js');
const axios = require('axios');
var errorLogger = appLoggers.errorLogger;
module.exports = async (req, res) => {
    try {
        if (!req.headers.apikey) {
            return {
                code: 403,
                status: 'FAILED',
                message: 'API Key is required',
                data: {}
            };
        }
        const apiKey = req.headers.apikey;
        const userId = await userService.getUserId(apiKey);
        if (!userId) {
            return {
                code: 400,
                status: 'FAILED',
                message: 'Correct API Key is required',
                data: {}
            };
        }

        if (!(req.body.tempid && req.body.tempid.length)) {
            return {
                code: 400,
                status: 'FAILED',
                message: 'tempid cannot be empty',
                data: {}
            };
        }

        const tempIdList = req.body.tempid;
        const AccessToken = await templateService.getSystemAccessToken();
        const access_token = AccessToken[0].value;
        const tempListResponse = await templateService.getTemplateDetails(tempIdList);
        const instanceUrl = 'https://graph.facebook.com/';

        await Promise.all(tempListResponse.map(async (item, index) => {
            
            let body = [];
            let tmpHeader = {};
            let mediaType;
            //https://{domainname}/assets/watemplates/'.$userid/filename
            try {
                const wafile = await axios.get(`https://th.bing.com/th/id/OIP.wdkLi0wAUuLf5gdNFincPwHaEd?w=308&h=185&c=7&o=5&dpr=1.25&pid=1.7`, {
                    responseType: 'arraybuffer'
                });
                const fileType = wafile.headers['content-type'];
                const fileLength = wafile.headers['content-length'];
                const fileBuffer = wafile.data;

                if (item.head_temptype == 0) { // text
                    tmpHeader.type = "HEADER";
                    tmpHeader.format = "TEXT";
                    tmpHeader.text = item.head_text_title;
                    body.push(tmpHeader);

                }
                if (item.head_temptype == 1) { // media

                    const mediaToken = await whatsappService.getUploadTokenAndSignature(instanceUrl, access_token, fileLength, fileType);
                    const uploadResonse = await whatsappService.whatsappMediaUpload(instanceUrl, access_token, mediaToken.id, fileBuffer);

                    if (item.head_mediatype == 0) {
                        mediaType = 'DOCUMENT'
                    } else if (item.head_mediatype == '1') {
                        mediaType = 'IMAGE'
                    } else {
                        mediaType = 'VIDEO'
                    }

                    tmpHeader.type = "HEADER";
                    tmpHeader.format = mediaType;
                    tmpHeader.example = {
                        "header_handle": [uploadResonse.h]
                    }
                    body.push(tmpHeader);

                };

                let tmpBody = {
                    "type": "BODY",
                    "text": Buffer.from(item.body_message, 'utf-8').toString()
                };


                if (item.placeholders != null) {
                    tmpBody.example = {
                        "body_text": []
                    };
                    let placeholderArr = item.placeholders.split(",");
                    if (placeholderArr.length > 0) {
                        let tmpBodyExample = [];
                        for (let arr = 0; arr < placeholderArr.length; ++arr) {
                            tmpBodyExample.push('test' + arr);
                        }
                        tmpBody.example.body_text.push(tmpBodyExample);
                    }
                }

                if (item.footer_text != null && item.footer_text.length > 0) {
                    let tmpFooter = {
                        "type": "FOOTER",
                        "text": item.footer_text
                    };
                    body.push(tmpFooter);
                }

                body.push(tmpBody);
                let buttonOptionBody = {};
                if (item.button_option != null) {
                    item.button_option_string = JSON.parse(item.button_option_string);
                    if (item.button_option == 0) {
                        buttonOptionBody.type = "BUTTONS";
                        buttonOptionBody.buttons = [];
                        for (let p = 0; p < item.button_option_string.length; ++p) {
                            if (item.button_option_string[p].call_phone != null &&
                                item.button_option_string[p].call_phone != undefined) {
                                let tmpButtonBody = {
                                    "type": "PHONE_NUMBER",
                                    "text": item.button_option_string[p].call_phone.phone_button_text,
                                    "phone_number": item.button_option_string[p].call_phone.phone_number
                                };
                                buttonOptionBody.buttons.push(tmpButtonBody);
                            }
                            if (item.button_option_string[p].visit_website != null &&
                                item.button_option_string[p].visit_website != undefined) {
                                let tmpButtonBody = {
                                    "type": "URL",
                                    "text": item.button_option_string[p].visit_website.web_button_text,
                                    "url": item.button_option_string[p].visit_website.web_url
                                }
                                buttonOptionBody.buttons.push(tmpButtonBody);
                            }
                        }
                    }
                    if (item.button_option == 1) {
                        buttonOptionBody.type = "BUTTONS";
                        buttonOptionBody.buttons = [];
                        for (let k = 0; k < item.button_option_string.length; ++k) {
                            let tmpButtonBody = {
                                "type": "QUICK_REPLY",
                                "text": item.button_option_string[k].quick_reply
                            }
                            buttonOptionBody.buttons.push(tmpButtonBody);
                        }
                    }
                }
                body.push(buttonOptionBody);
                //console.log(JSON.stringify(body));

                const generateTempID = await whatsappService.messageTemplate(item.temptitle, item.category, item.langcode, body, access_token);
                if (!generateTempID){
                    console.log(JSON.stringify(body));  
                }
                await templateService.updateMsgResponseId(tempIdList[index], generateTempID.id);
                setImmediate(async () => {
                        //1. Fetch template by id -- updateResponceId.id
                        const templateStatus = await whatsappService.getMsgTemplateStatus(item.temptitle, access_token);
                        let statusCode;
                        if (templateStatus == 'REJECTED') {
                            statusCode = 2;
                        } else if (templateStatus == 'APPROVED') {
                            statusCode = 1;
                        } else {
                            statusCode = 0;;
                        }
                        await templateService.updateMsgTemplateStatus(statusCode, item.temptitle);
                    });

                return;
            } catch (error) {
                errorLogger.error(JSON.stringify(error));
                return;
            }
        }));
        return {
            code: 200,
            status: 'SUCCESS',
            message: 'Templates Created',
        };
    } catch (error) {
        console.log(error);
        //errorLogger.error(JSON.stringify(error));
        return error;
    }
}