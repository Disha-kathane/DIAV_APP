const dbpool= require('../db/wabot');
const PropertiesReader = require('properties-reader');
const path = require('path');
const async = require('async');
const validator = require('validator');
const moment = require('moment');

const { errorLogger, infoLogger } = require('../applogger');
const botUtils = require('../utils/bot');
const properties = PropertiesReader(path.join(__dirname,'../settings/application.properties'));

module.exports = (req, res) => {
    var botId = null; //(typeof req.params.botid != 'undefined')?req.params.botid+'':'';
    var headers = req.headers;
    var apiKey = (typeof headers.apikey != 'undefined') ? headers.apikey + '' : '';
    var messageObj = req.body;
    var instanceUrl = '';
    var authToken = '';
    var isDeactivatedBot = false;
    var waUsername = '';
    var waPassword = '';
    var generateAuthenticationToken = false;
    var authDaysLimit = 6; //days
    var error = false;
    var errCode = 'WA000';
    var errMsg = 'Sorry, unable to process request';
    var countryCode = properties.get('country.code.text');
    var waid = '';
    var wanumber = '';
    var senderId = '';
    var sessionId = '';
    var sessionLatestLogTime = '';
    var aggSession = 0;
    var aggButton = 0;
    var aggInbound = 0;
    var aggOutbound = 0;
    var aggSms = 0;
    var aggEmail = 0;
    var msgType = 0; //free
    var msgChannel = 2; //whatsapp
    var waMessageId = '';
    var strLogMessage = '';
    var hsmnamespace = '';
    var hsmtitle = '';
    var temptype = '';
    var langcode = '';
    var waChargeCriteria = 1; //default to both incoming and outgoing message
    var countryCodeNumeric = properties.get('country.code.numeric');
    var waHsmCost = 0.0;
    var waNonHsmCost = 0.0;
    var maxTextLength = 4000;
    var moduleid = (typeof messageObj.gotomodule != 'undefined') ? parseInt(messageObj.gotomodule) : 0;
    var messageType = 'SESSION';
    var chatAgentId = 0;
    var chatTicketId = 0;
    var whatsappMediaId = '';
    var whatsappMediaFileName = '';
    var whatsappMediaType = -1;
    var hsmMediaType = "";
    var mediaMetaData = "";
    var memCosting = {
        'configured': false,
        'type': 0,
        'hsm': 0.0,
        'nonhsm': 0.0,
        'text': 0.0,
        'image': 0.0,
        'audio': 0.0,
        'video': 0.0,
        'document': 0.0,
        'location': 0.0
    };
    var validateMediaId = false;
    var bot = {
        botname: '',
        avatar: '',
        botid: '',
        desc: '',
        userid: 0,
        moduleid: 0
    };
    var skipOptinCheck = false;
    var logObj = JSON.parse(JSON.stringify(messageObj));
    if (typeof messageObj.message != 'undefined' && typeof messageObj.message.text != 'undefined') {
        let strMessageText = messageObj.message.text;
        logObj.message.text = strMessageText.substr(0, 100);
    }
    let strLog = apiKey + " " + JSON.stringify(logObj);
    var validateApiKey = function (callback) {
        //console.log('validateApiKey');
        var query = 'SELECT `botid`,`apikey` FROM `ezb_wa_api_keys` WHERE `apikey`=? AND `kstatus`=?';
        var values = [apiKey, 1];
        dbpool.query(query, values, function (err, result) {
            if (err) {
                errorLogger.info(strLog);
                error = true;
                errorLogger.error(JSON.stringify(err));
                callback(null, {
                    success: 0
                });
                return;
            }
            var success = 0;
            if (result != null && result.length > 0) {
                botId = result[0].botid;
                success = 1;
                strLog = botId + " " + strLog;
            } else {
                error = true;
                errCode = 'WA010';
                errMsg = 'Authentication failed';
            }
            errorLogger.info(strLog);
            callback(null, {
                success: success
            });
        });
    };
    var selectBot = function (obj, callback) {
        //console.log('selectBot');
        //console.log(obj);
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        var query = "SELECT `botid`,`botname`,`botdesc`,`avatar`,`userid`,`botstatus` FROM `ezb_bots` WHERE `botid`=? AND `botstatus`=?";
        var values = [botId, 1];
        dbpool.query(query, values, function (err, result) {
            if (err) {
                error = true;
                errorLogger.error(JSON.stringify(err));
                callback(null, {
                    success: 0
                });
                return;
            }
            var success = 0;
            if (result != null && result.length > 0) {
                bot.botname = result[0].botname;
                bot.avatar = result[0].avatar;
                bot.botid = result[0].botid;
                bot.desc = result[0].botdesc;
                bot.userid = result[0].userid;
                if (parseInt(result[0].botstatus) == 0) {
                    isDeactivatedBot = true;
                    callback(null, {
                        success: 0
                    });
                    return;
                } else {
                    success = 1;
                }
            }
            callback(null, {
                success: success
            });
        });
    };
    var getWaSettings = function (obj, callback) {
        //console.log('getWaSettings');
        //console.log(obj);
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        var query = 'SELECT `waurl`,`authtoken`,`usrnm`,`usrpass`,`chargeon`,DATEDIFF(NOW(),`authts`) AS `authdays` FROM `ezb_wa_msg_settings` WHERE `botid`=?';
        var values = [botId];
        dbpool.query(query, values, function (err, results) {
            if (err) {
                error = true;
                errorLogger.error(JSON.stringify(err));
                callback(null, {
                    success: 0
                });
                return;
            }
            if (results != null && results.length > 0) {
                instanceUrl = results[0].waurl;
                authToken = results[0].authtoken;
                waUsername = results[0].usrnm;
                waPassword = results[0].usrpass;
                waChargeCriteria = parseInt(results[0].chargeon);
                if (parseInt(results[0].authdays) >= authDaysLimit || authToken == null || validator.isEmpty(authToken + '')) {
                    generateAuthenticationToken = true;
                }
                callback(null, {
                    success: 1
                });
                return;
            } else {
                isDeactivatedBot = true;
                callback(null, {
                    success: 0
                });
                return;
            }
        });
    };
    var validateRequest = function (obj, callback) {
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        if (typeof messageObj.to == 'undefined' || validator.isEmpty(messageObj.to + '') || messageObj.to == null) {
            error = true;
            errCode = 'WA001';
            errMsg = 'Recipient number missing';
        } else if (typeof messageObj.type == 'undefined' || validator.isEmpty(messageObj.type + '') || messageObj.type == null) {
            error = true;
            errCode = 'WA002';
            errMsg = 'Message type is required';
        } else if (typeof messageObj.message == 'undefined' || messageObj.message == null || messageObj.message.length == 0) {
            error = true;
            errCode = 'WA003';
            errMsg = 'Message is required';
        }
        var validateUrl = false;
        if (!error) {
            messageObj.type += "";
            var msgType = messageObj.type.toLowerCase();
            var objMessage = messageObj.message;
            switch (msgType) {
                case "hsm":
                    if (typeof objMessage.templateid == 'undefined' || validator.isEmpty(objMessage.templateid + '')) {
                        error = true;
                        errCode = 'WA004';
                        errMsg = 'Templateid is required';
                    }
                    break;
                case "template":
                    if (typeof objMessage.templateid == 'undefined' || validator.isEmpty(objMessage.templateid + '')) {
                        error = true;
                        errCode = 'WA004';
                        errMsg = 'Templateid is required';
                    }
                    if (!error) {
                        if (typeof objMessage.buttons != 'undefined') {
                            if (objMessage.buttons.length > 0) {
                                if (typeof objMessage.url != 'undefined' && validator.isEmpty(objMessage.url + '') !== true) {
                                    validateUrl = true;
                                } else if (typeof objMessage.mediaid != 'undefined' && validator.isEmpty(objMessage.mediaid + '') !== true) {
                                    whatsappMediaId = botUtils.stripTags(objMessage.mediaid);
                                    whatsappMediaId = botUtils.filterInput(objMessage.mediaid);
                                    validateMediaId = true;
                                }
                            }
                        } else {
                            if (typeof objMessage.mediaid != 'undefined' && !validator.isEmpty(objMessage.mediaid + '')) {
                                whatsappMediaType = 0;
                                whatsappMediaId = botUtils.stripTags(objMessage.mediaid);
                                whatsappMediaId = botUtils.filterInput(objMessage.mediaid);
                                validateMediaId = true;
                            } else {
                                if (typeof objMessage.url == 'undefined' || validator.isEmpty(objMessage.url + '')) {
                                    error = true;
                                    errCode = 'WA006';
                                    errMsg = 'url/mediaid is required';
                                }
                                validateUrl = true;
                            }
                        }
                    }
                    break;
                case "text":
                    if (typeof objMessage.text == 'undefined' || validator.isEmpty(objMessage.text + '')) {
                        error = true;
                        errCode = 'WA005';
                        errMsg = 'text is required';
                    } else if (typeof objMessage.text != 'undefined' && (objMessage.text + '').length > maxTextLength) {
                        error = true;
                        errCode = 'WA005';
                        errMsg = 'text cannot exceed 4000 characters';
                    }
                    break;
                case "audio":
                    if (typeof objMessage.mediaid != 'undefined' && !validator.isEmpty(objMessage.mediaid + '')) {
                        whatsappMediaType = 0;
                        whatsappMediaId = botUtils.stripTags(objMessage.mediaid);
                        whatsappMediaId = botUtils.filterInput(objMessage.mediaid);
                        validateMediaId = true;
                    } else {
                        if (typeof objMessage.url == 'undefined' || validator.isEmpty(objMessage.url + '')) {
                            error = true;
                            errCode = 'WA006';
                            errMsg = 'url/mediaid is required';
                        }
                        validateUrl = true;
                    }
                    break;
                case "video":
                    if (typeof objMessage.mediaid != 'undefined' && !validator.isEmpty(objMessage.mediaid + '')) {
                        whatsappMediaType = 1;
                        whatsappMediaId = botUtils.stripTags(objMessage.mediaid);
                        whatsappMediaId = botUtils.filterInput(objMessage.mediaid);
                        validateMediaId = true;
                    } else {
                        if (typeof objMessage.url == 'undefined' || validator.isEmpty(objMessage.url + '')) {
                            error = true;
                            errCode = 'WA006';
                            errMsg = 'url/mediaid is required';
                        }
                        validateUrl = true;
                    }
                    break;
                case "image":
                    if (typeof objMessage.mediaid != 'undefined' && !validator.isEmpty(objMessage.mediaid + '')) {
                        whatsappMediaType = 2;
                        whatsappMediaId = botUtils.stripTags(objMessage.mediaid);
                        whatsappMediaId = botUtils.filterInput(objMessage.mediaid);
                        validateMediaId = true;
                    } else {
                        if (typeof objMessage.url == 'undefined' || validator.isEmpty(objMessage.url + '')) {
                            error = true;
                            errCode = 'WA006';
                            errMsg = 'url/mediaid is required';
                        }
                        validateUrl = true;
                    }
                    break;
                case "document":
                    if (typeof objMessage.mediaid != 'undefined' && !validator.isEmpty(objMessage.mediaid + '')) {
                        whatsappMediaType = 3;
                        whatsappMediaId = botUtils.stripTags(objMessage.mediaid);
                        whatsappMediaId = botUtils.filterInput(objMessage.mediaid);
                        validateMediaId = true;
                    } else {
                        if (typeof objMessage.url == 'undefined' || validator.isEmpty(objMessage.url + '')) {
                            error = true;
                            errCode = 'WA006';
                            errMsg = 'url/mediaid is required';
                        }
                        validateUrl = true;
                    }
                    break;
                case "location":
                    if (typeof objMessage.longitude == 'undefined' || validator.isEmpty(objMessage.longitude + '')) {
                        error = true;
                        errCode = 'WA013';
                        errMsg = 'longitude is required';
                    } else if (typeof objMessage.latitude == 'undefined' || validator.isEmpty(objMessage.latitude + '')) {
                        error = true;
                        errCode = 'WA014';
                        errMsg = 'latitude is required';

                    } else if (typeof objMessage.name == 'undefined' || validator.isEmpty(objMessage.name + '')) {
                        error = true;
                        errCode = 'WA015';
                        errMsg = 'location name is required';
                    } else if (typeof objMessage.address == 'undefined' || validator.isEmpty(objMessage.address + '')) {
                        error = true;
                        errCode = 'WA016';
                        errMsg = 'location address is required';
                    } else {
                        var latLon = objMessage.latitude + ',' + objMessage.longitude;
                        if (!validator.isLatLong(latLon)) {
                            error = true;
                            errCode = 'WA017';
                            errMsg = 'Invalid coordinates for location';
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        if (error) {
            callback(null, {
                success: 0
            });
            return;
        } else {
            if (validateUrl) {
                if (!validator.isURL(objMessage.url + '') || objMessage.url.indexOf('https:') == -1) {
                    error = true;
                    errCode = 'WA007';
                    errMsg = 'Media url provided is invalid';
                    callback(null, {
                        success: 0
                    });
                    return;
                }
            }
            wanumber = (typeof messageObj.to != 'undefined' && messageObj.to != null) ? messageObj.to : '';
            //format the mobile number
            if (botUtils.isMobileInternational(wanumber)) {
                //senderId = wanumber;
                countryCode = botUtils.getCountryCode(wanumber);
                countryCodeNumeric = botUtils.getCountryCodeNumeric(wanumber);
                wanumber = botUtils.formatMobileLocal(wanumber, countryCode);
                waid = botUtils.formatMobileWhatsapp(wanumber, countryCode);
            } else {
                //senderId = botUtils.formatMobileInternational(wanumber);
                wanumber = botUtils.formatMobileLocal(wanumber, countryCode);
                waid = botUtils.formatMobileWhatsapp(wanumber, countryCode);
            }
            callback(null, {
                success: 1
            });
            return;
        }
    };
    var fetchTemplate = function (obj, callback) {
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        if (messageObj.type.toLowerCase() != "hsm" && messageObj.type.toLowerCase() != "template") {
            callback(null, {
                success: 1
            });
            return;
        }
        var templateid = messageObj.message.templateid + '';
        templateid = templateid.toLowerCase();
        templateid = templateid.replace('pbwa', '');
        templateid = parseInt(templateid); //remove pbwa prefix
        var query = 'SELECT `temptext`,`hsmnamespace`,`mediatype`,`hsmtitle`,`temptype`,`langcode` FROM `ezb_wa_templates` WHERE `tempid`=? AND `botid`=? AND `tempstatus`=?';
        var values = [templateid, botId, 1];
        dbpool.query(query, values, function (err, results) {
            if (err) {
                errorLogger.error(JSON.stringify(err));
                error = true;
                errCode = 'WA009';
                errMsg = 'Message template not found';
                callback(null, {
                    success: 0
                });
                return;
            }
            if (results != null && results.length > 0) {
                strLogMessage = "pbwa" + templateid + " : " + botUtils.stripTags(results[0].temptext);
                hsmnamespace = results[0].hsmnamespace;
                hsmtitle = results[0].hsmtitle;
                langcode = results[0].langcode;
                if (messageObj.type.toLowerCase() == "template") {
                    if (results[0].temptype == 'media') {

                        if (messageObj.message.url && messageObj.message.mediaid) {
                            errCode = 'WA009';
                            errMsg = 'Template is of type media';
                            callback(null, {
                                success: 0
                            });
                            return;
                        }

                        if (results[0].mediatype == 0) { //document
                            temptype = 'document';
                            whatsappMediaType = 3;
                            if (typeof messageObj.message.mediaid != 'undefined' && !validator.isEmpty(messageObj.message.mediaid + '')) {
                                hsmMediaType = "id";
                                mediaMetaData = messageObj.message.mediaid;
                                callback(null, {
                                    success: 1
                                });
                                return;
                            } else {
                                hsmMediaType = "link";
                                mediaMetaData = (typeof messageObj.message.url != 'undefined') ? messageObj.message.url : '';
                                let indexOfUrl = (typeof messageObj.message.url != 'undefined') ? messageObj.message.url.length : 0;
                                let indexOfExtension = (typeof messageObj.message.url != 'undefined') ? messageObj.message.url.indexOf('.', messageObj.message.url.lastIndexOf('/') + 1) : -1;
                                //let indexOfExtension=messageObj.message.url.lastIndexOf(".");
                                if (indexOfExtension != -1) {
                                    let indexOfSubstring = indexOfUrl - indexOfExtension;
                                    let extension = messageObj.message.url.substr(indexOfSubstring - (indexOfSubstring * 2));
                                    extension = extension.substring(0);
                                    let mediaAllowedExtensions = ['.pdf'];
                                    if (extension == mediaAllowedExtensions[0]) {
                                        callback(null, {
                                            success: 1
                                        });
                                        return;
                                    } else {
                                        error = true;
                                        errCode = 'WA103';
                                        errMsg = 'Document extension must be .pdf';
                                        callback(null, {
                                            success: 0
                                        });
                                        return;
                                    }
                                } else {
                                    callback(null, {
                                        success: 1
                                    });
                                    return;
                                }
                            }
                        } else if (results[0].mediatype == 1) { //image
                            temptype = 'image';
                            whatsappMediaType = 2;
                            if (typeof messageObj.message.mediaid != 'undefined' && !validator.isEmpty(messageObj.message.mediaid + '')) {
                                hsmMediaType = "id";
                                mediaMetaData = messageObj.message.mediaid;
                                callback(null, {
                                    success: 1
                                });
                                return;
                            } else {
                                hsmMediaType = "link";
                                mediaMetaData = (typeof messageObj.message.url != 'undefined') ? messageObj.message.url : '';
                                let indexOfUrl = (typeof messageObj.message.url != 'undefined') ? messageObj.message.url.length : 0;
                                let indexOfExtension = (typeof messageObj.message.url != 'undefined') ? messageObj.message.url.indexOf('.', messageObj.message.url.lastIndexOf('/') + 1) : -1;
                                if (indexOfExtension != -1) {
                                    let indexOfSubstring = indexOfUrl - indexOfExtension;
                                    let extension = messageObj.message.url.substr(indexOfSubstring - (indexOfSubstring * 2));
                                    extension = extension.substring(0);
                                    if (extension != '.jpeg' && extension != '.jpg' && extension != '.png') {
                                        error = true;
                                        errCode = 'WA104';
                                        errMsg = 'Image extension must be .jpeg or .jpg or .png';
                                        callback(null, {
                                            success: 0
                                        });
                                        return;
                                    } else {
                                        callback(null, {
                                            success: 1
                                        });
                                        return;
                                    }
                                } else {
                                    callback(null, {
                                        success: 1
                                    });
                                    return;
                                }
                            }
                        } else if (results[0].mediatype == 2) { //video
                            temptype = 'video';
                            whatsappMediaType = 1;
                            if (typeof messageObj.message.mediaid != 'undefined' && !validator.isEmpty(messageObj.message.mediaid + '')) {
                                hsmMediaType = "id";
                                mediaMetaData = messageObj.message.mediaid;
                                callback(null, {
                                    success: 1
                                });
                                return;
                            } else {
                                hsmMediaType = "link";
                                mediaMetaData = (typeof messageObj.message.url != 'undefined') ? messageObj.message.url : '';
                                let indexOfUrl = (typeof messageObj.message.url != 'undefined') ? messageObj.message.url.length : '';
                                let indexOfExtension = (typeof messageObj.message.url != 'undefined') ? messageObj.message.url.indexOf('.', messageObj.message.url.lastIndexOf('/') + 1) : -1;
                                if (indexOfExtension != -1) {
                                    let indexOfSubstring = indexOfUrl - indexOfExtension;
                                    let extension = messageObj.message.url.substr(indexOfSubstring - (indexOfSubstring * 2));
                                    extension = extension.substring(0);
                                    if (extension != '.mp4') {
                                        error = true;
                                        errCode = 'WA104';
                                        errMsg = 'Video extension must be .mp4';
                                        callback(null, {
                                            success: 0
                                        });
                                        return;
                                    } else {
                                        callback(null, {
                                            success: 1
                                        });
                                        return;
                                    }
                                } else {
                                    callback(null, {
                                        success: 1
                                    });
                                    return;
                                }
                            }
                        }
                    } else {
                        callback(null, {
                            success: 1
                        });
                        return;
                    }
                } else if (messageObj.type.toLowerCase() == "hsm") {
                    callback(null, {
                        success: 1
                    });
                }
            } else {
                error = true;
                errCode = 'WA009';
                errMsg = 'Message template not found';
                callback(null, {
                    success: 0
                });
                return;
            }
        });
    };
    var checkMediaId = function (obj, callback) {
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        if (validateMediaId) {
            let query = "SELECT `mediatype`,`medianame` FROM `ezb_wa_media` WHERE `botid`=? AND `mediaid`=?";
            let values = [botId, whatsappMediaId];
            dbpool.query(query, values, function (err, result) {
                if (err) {
                    errorLogger.error(JSON.stringify(err));
                    callback(null, {
                        success: 0
                    });
                    return;
                }
                if (result == null || result.length == 0) {
                    error = true;
                    errCode = 'WA007';
                    errMsg = 'Media id provided is invalid';
                    callback(null, {
                        success: 0
                    });
                    return;
                } else {
                    if (whatsappMediaType != parseInt(result[0].mediatype)) {
                        error = true;
                        errCode = 'WA020';
                        errMsg = 'Media id and type provided does not match';
                        callback(null, {
                            success: 0
                        });
                        return;
                    } else {
                        whatsappMediaFileName = result[0].medianame;
                        callback(null, {
                            success: 1
                        });
                        return;
                    }
                }
            });
        } else {
            callback(null, {
                success: 1
            });
            return;
        }
    };
    var checkPrivilege = function (obj, callback) {
        //console.log('checkPrivilege');
        //console.log(obj);
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        var query = "SELECT `ezb_privileges`.`privname`,`privdisplayname`,`privstatus`,`userid` FROM `ezb_privileges`" +
            " INNER JOIN `ezb_user_privileges` ON `ezb_user_privileges`.`privname`=`ezb_privileges`.`privname`" +
            " WHERE `userid`=? AND `privstatus`=1";
        var values = [bot.userid];
        dbpool.query(query, values, function (err, result) {
            if (err) {
                errorLogger.error(JSON.stringify(err));
                callback(null, {
                    success: 0
                });
                return;
            }
            if (result != null && result.length > 0) {
                for (var i = 0; i < result.length; i++) {
                    if (validator.equals(result[i].privname, 'SKIPWAOPTIN')) {
                        skipOptinCheck = true;
                        break;
                    }
                }
                if (skipOptinCheck == false) {
                    query = "SELECT `ezb_chat_sessions`.`sessid`,`ezb_chat_logs`.`loggedat`,TIMESTAMPDIFF(MINUTE,`ezb_chat_logs`.`loggedat`,NOW()) AS `latestlog` FROM `ezb_chat_sessions` INNER JOIN `ezb_chat_logs` ON `ezb_chat_logs`.`sessid`=`ezb_chat_sessions`.`sessid` WHERE `ezb_chat_sessions`.`botid`=? AND `ezb_chat_sessions`.`mobile`=? AND `ezb_chat_sessions`.`initby`=? ORDER BY `ezb_chat_logs`.`loggedat` DESC LIMIT 1";
                    values = [bot.botid, wanumber, 0];
                    dbpool.query(query, values, function (err, result) {
                        if (err) {
                            errorLogger.error(JSON.stringify(err));
                            callback(null, {
                                success: 0
                            });
                            return;
                        }
                        if (result != null && result.length > 0) {
                            if (result[0].latestlog <= 1440) { //24 hours = 1440 minutes
                                skipOptinCheck = true;
                            }
                        }
                        callback(null, {
                            success: 1
                        });
                    });
                } else {
                    callback(null, {
                        success: 1
                    });
                }
            } else {
                query = "SELECT `ezb_chat_sessions`.`sessid`,`ezb_chat_logs`.`loggedat`,TIMESTAMPDIFF(MINUTE,`ezb_chat_logs`.`loggedat`,NOW()) AS `latestlog` FROM `ezb_chat_sessions` INNER JOIN `ezb_chat_logs` ON `ezb_chat_logs`.`sessid`=`ezb_chat_sessions`.`sessid` WHERE `ezb_chat_sessions`.`botid`=? AND `ezb_chat_sessions`.`mobile`=? AND `ezb_chat_sessions`.`initby`=? ORDER BY `ezb_chat_logs`.`loggedat` DESC LIMIT 1";
                values = [bot.botid, wanumber, 0];
                dbpool.query(query, values, function (err, result) {
                    if (err) {
                        errorLogger.error(JSON.stringify(err));
                        callback(null, {
                            success: 0
                        });
                        return;
                    }
                    if (result != null && result.length > 0) {
                        if (result[0].latestlog <= 1440) { //24 hours = 1440 minutes
                            skipOptinCheck = true;
                        }
                    }
                    callback(null, {
                        success: 1
                    });
                });
            }

        });
    };
    var generateAuthToken = function (obj, callback) {
        //console.log('generateAuthToken');
        //console.log(obj);
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        if (generateAuthenticationToken == false) {
            callback(null, {
                success: 1
            });
            return;
        }
        //make api call to generate auth token
        var objData = {
            "new_password": waPassword
        };
        var api = '/v1/users/login';
        var httpMethod = 1;
        var requestType = 1;
        var contentLength = Buffer.byteLength(JSON.stringify(objData));
        var base64Creds = Buffer.from(waUsername + ":" + waPassword).toString('base64');
        var apiHeaders = [{
            'headerName': 'Authorization',
            'headerVal': 'Basic ' + base64Creds
        }, {
            'headerName': 'content-length',
            'headerVal': contentLength
        }];
        botUtils.callWhatsAppApi(instanceUrl, api, objData, httpMethod, requestType, apiHeaders).then(function (response) {
            if (typeof response.users[0].token != 'undefined') {
                authToken = response.users[0].token;
                var query = 'UPDATE `ezb_wa_msg_settings` SET `authtoken`=?,`authts`=NOW() WHERE `botid`=?';
                var values = [authToken, botId];
                dbpool.query(query, values, function (err, results) {
                    if (err) {
                        error = true;
                        errorLogger.error(JSON.stringify(err));
                        callback(null, {
                            success: 0
                        });
                        return;
                    }
                    callback(null, {
                        success: 1
                    });
                    return;
                });
            } else {
                callback(null, {
                    success: 0
                });
                return;
            }
        }).catch(function (response) {
            error = true;
            errorLogger.error(response);
            callback(null, {
                success: 0
            });
            return;
        });
    };
    var checkContact = function (obj, callback) {
        //console.log('checkContact');
        //console.log(obj);
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        var query = 'SELECT * FROM `ezb_wa_contacts` USE INDEX(ind_bot_number) WHERE `botid`=? AND `wanumber`=?';
        var values = [botId, wanumber];
        dbpool.query(query, values, function (err, result) {
            if (err) {
                errorLogger.error(JSON.stringify(err));
                error = true;
                errCode = 'WA008';
                errMsg = 'Contact does not exist';
                callback(null, {
                    success: 0
                });
                return;
            }
            if (result != null && result.length > 0) {
                waid = result[0].waid;
                if (botUtils.isMobileInternational(waid)) {
                    //senderId = wanumber;
                    countryCode = botUtils.getCountryCode(wanumber);
                    waid = botUtils.formatMobileWhatsapp(wanumber, countryCode);
                } else {
                    waid = botUtils.formatMobileWhatsapp(wanumber, countryCode);
                }
                if (skipOptinCheck && result[0].wastatus == 0) {
                    error = true;
                    errCode = 'WA008';
                    errMsg = 'Contact does not exist';
                    callback(null, {
                        success: 0
                    });
                    return;
                }
                callback(null, {
                    success: 1
                });
                return;
            } else {
                // if(!skipOptinCheck){
                //     error=true;
                //     errCode='WA008';
                //     errMsg='Contact does not exist';
                //     callback(null,{success:0});
                //     return;
                // }
                callback(null, {
                    success: 1
                });
                return;
            }
        });
    };
    var addContact = function (obj, callback) {
        //console.log('addContact');
        //console.log(obj);
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        // commented to 27-03-2020
        // if(!skipOptinCheck){
        //     callback(null,{success:1});
        //     return;
        // }
        //call wa contact api
        var api = '/v1/contacts';
        var objData = {
            "blocking": "wait",
            "contacts": [waid]
        };
        var httpMethod = 1;
        var requestType = 1;
        var contentLength = Buffer.byteLength(JSON.stringify(objData));
        //console.log(instanceUrl+api);
        //console.log(objData);
        var apiHeaders = [{
            'headerName': 'Authorization',
            'headerVal': 'Bearer ' + authToken
        }, {
            'headerName': 'content-length',
            'headerVal': contentLength
        }];
        botUtils.callWhatsAppApi(instanceUrl, api, objData, httpMethod, requestType, apiHeaders).then(function (response) {
            //console.log(response);
            if (typeof response.contacts != 'undefined' && typeof response.contacts[0] != 'undefined') {
                var contact = response.contacts[0];
                if (typeof contact.status != 'undefined' && validator.equals(contact.status + '', 'valid')) {
                    if (skipOptinCheck) { //do not save to database
                        callback(null, {
                            success: 1
                        });
                        return;
                    }
                    waid = contact.wa_id;
                    var query = "REPLACE INTO `ezb_wa_contacts`(`botid`,`wanumber`,`waid`) VALUES(?,?,?)";
                    var values = [botId, wanumber, waid];
                    dbpool.query(query, values, function (err, result) {
                        if (err) {
                            errorLogger.error(JSON.stringify(err));
                            callback(null, {
                                success: 0
                            });
                            return;
                        }
                        callback(null, {
                            success: 1
                        });
                        return;
                    });
                } else {
                    error = true;
                    errCode = 'WA008';
                    errMsg = 'Contact does not exist';
                    callback(null, {
                        success: 0
                    });
                    return;
                }
            } else {
                error = true;
                errCode = 'WA008';
                errMsg = 'Contact does not exist';
                callback(null, {
                    success: 0
                });
                return;
            }
        }).catch(function (response) {
            errorLogger.error(response);
            callback(null, {
                success: 0
            });
            return;
        });
    };
    var moduleExists = function (obj, callback) {
        //console.log('moduleExists');
        //console.log(obj);
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        if (parseInt(moduleid) == 0) { //reset to init module
            callback(null, {
                success: 1
            });
            return;
        }
        var query = 'SELECT `modulename` FROM `ezb_chatmodules` WHERE `botid`=? AND `moduleid`=?';
        var values = [botId, moduleid];
        dbpool.query(query, values, function (err, results) {
            if (err) {
                error = true;
                errorLogger.error(JSON.stringify(err));
                callback(null, {
                    success: 0
                });
                return;
            }
            if (results != null && results.length > 0) {
                callback(null, {
                    success: 1
                });
                return;
            } else {
                error = true;
                errCode = 'WA012';
                errMsg = 'Module does not exist';
                callback(null, {
                    success: 0
                });
                return;
            }
        });
    };
    var chatSession = function (obj, callback) {
        //console.log('chatSession');
        //console.log(obj);
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        var waSessId = botUtils.mkWhatsappSessionId(bot, wanumber);
        //console.log('waSessId ' + waSessId);
        var query = "SELECT * FROM `ezb_chat_sessions` WHERE `sessid`=? ORDER BY `createdat` DESC LIMIT 1";
        var values = [waSessId];
        dbpool.query(query, values, function (err, results) {
            if (err) {
                error = true;
                errorLogger.error(JSON.stringify(err));
                callback(null, {
                    success: 0
                });
                return;
            }
            if (results != null && results.length > 0) {
                //find if time of the last incoming message for this wanumber
                chatAgentId = (parseInt(results[0].agentid)) ? parseInt(results[0].agentid) : 0;
                chatTicketId = (parseInt(results[0].lcticketid)) ? parseInt(results[0].lcticketid) : 0;
                sessionId = results[0].sessid;
                var query = 'SELECT `loggedat` FROM `ezb_chat_logs` USE INDEX (ind_chat_botsessdir) WHERE `botid`=? AND `sessid`=? AND `direction`=? ORDER BY `loggedat` DESC LIMIT 1';
                var values = [botId, waSessId, 0];
                dbpool.query(query, values, function (err, results) {
                    if (err) {
                        error = true;
                        errorLogger.error(JSON.stringify(err));
                        callback(null, {
                            success: 0
                        });
                        return;
                    }
                    if (results != null && results.length > 0) {
                        sessionLatestLogTime = results[0].loggedat;
                    }
                    if (parseInt(moduleid) > 0) {
                        var query = 'UPDATE `ezb_chat_sessions` SET `flowlevel`=? WHERE `botid`=? AND `sessid`=?';
                        var values = [moduleid, botId, waSessId];
                        dbpool.query(query, values, function (err, results) {
                            if (err) {
                                error = true;
                                errorLogger.error(JSON.stringify(err));
                                callback(null, {
                                    success: 0
                                });
                                return;
                            }
                            callback(null, {
                                success: 1
                            });
                            return;
                        });
                    } else {
                        callback(null, {
                            success: 1
                        });
                        return;
                    }
                });
            } else {
                //generate new session id
                sessionId = waSessId;
                aggSession = 1;
                var query = 'INSERT INTO `ezb_chat_sessions`(`botid`,`sessid`,`mobile`,`flowlevel`,`chatstatus`,`createdat`,`initby`) VALUES (?,?,?,?,?,NOW(),?)';
                var values = [botId, sessionId, wanumber, 0, 0, 1];
                dbpool.query(query, values, function (err, results) {
                    if (err) {
                        error = true;
                        errorLogger.error(JSON.stringify(err));
                        callback(null, {
                            success: 0
                        });
                        return;
                    }
                    callback(null, {
                        success: 1
                    });
                    return;
                });
            }
        });
    };
    var saveAttribute = function (obj, callback) {
        //console.log('saveAttribute');
        //console.log(obj);
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        var moduleAttributes = (typeof messageObj.moduleattributes != 'undefined') ? messageObj.moduleattributes : [];
        if (moduleAttributes.length == 0) {
            callback(null, {
                success: 1
            });
            return;
        }
        var insertattribute = function () {
            if (moduleAttributes.length == 0) {
                callback(null, {
                    success: 1
                });
                return;
            }
            let moduleAttributesobj = moduleAttributes.pop();
            if (moduleAttributesobj.attrname != undefined && moduleAttributesobj.attrvalue != undefined) {
                var attrkey = moduleAttributesobj.attrname;
                var attrvalue = moduleAttributesobj.attrvalue;
                if (attrvalue != null && attrvalue + ''.length > 1000) {
                    attrvalue = attrvalue.substr(0, 1000);
                }
                var query = "REPLACE INTO `ezb_chat_attributes` (`botid`,`sessid`,`attrkey`,`attrval`) VALUES(?,?,?,?)";
                var values = [botId, sessionId, attrkey, attrvalue];
                dbpool.query(query, values, function (err, result) {
                    if (err) {
                        error = true;
                        errorLogger.error(JSON.stringify(err));
                        callback(null, {
                            success: 0
                        });
                        return;
                    }
                    insertattribute();
                });
            } else {
                callback(null, {
                    success: 1
                });
                return;
            }
        }
        insertattribute();
    };
    var getMessageCosting = function (obj, callback) {
        //console.log('getMessageCosting');
        //console.log(obj);
        if (parseInt(obj.success) == 0) {
            callback(null, {
                success: 0
            });
            return;
        }
        var query = "SELECT * FROM `ezb_wa_mem_cost` WHERE `userid`=?";
        var values = [bot.userid];
        dbpool.query(query, values, function (err, result) {
            if (err) {
                errorLogger.error(JSON.stringify(err));
                callback(null, {
                    success: 0
                });
                return;
            }
            if (result != null && result.length > 0) {
                memCosting.configured = true;
                memCosting.type = parseInt(result[0].billingtype);
                memCosting.hsm = result[0].hsm_cost;
                memCosting.nonhsm = result[0].fixed_cost;
                if (memCosting.type == 0) {
                    memCosting.text = result[0].text_cost;
                    memCosting.image = result[0].image_cost;
                    memCosting.video = result[0].video_cost;
                    memCosting.audio = result[0].audio_cost;
                    memCosting.document = result[0].document_cost;
                    memCosting.location = result[0].location_cost;
                }
                callback(null, {
                    success: 1
                });
                return;
            } else {
                var query = "SELECT * FROM `ezb_wa_charges` WHERE `countrycode`=? AND `pstatus`=?";
                var values = [countryCodeNumeric, 1];
                dbpool.query(query, values, function (err, result) {
                    if (err) {
                        errorLogger.error(JSON.stringify(err));
                        callback(null, {
                            success: 0
                        });
                        return;
                    }
                    if (result != null && result.length > 0) {
                        //waHsmCost = result[0].hsm;
                        //waNonHsmCost = result[0].nonhsm;
                        memCosting.hsm = result[0].hsm;
                        memCosting.nonhsm = result[0].nonhsm;
                        callback(null, {
                            success: 1
                        });
                        return;
                    } else {
                        var query = "SELECT * FROM `ezb_wa_charges` WHERE `countrycode`=? AND `pstatus`=?";
                        var values = [0, 1];
                        dbpool.query(query, values, function (err, result) {
                            if (err) {
                                errorLogger.error(JSON.stringify(err));
                                callback(null, {
                                    success: 0
                                });
                                return;
                            }
                            if (result != null && result.length > 0) {
                                //waHsmCost = result[0].hsm;
                                //waNonHsmCost = result[0].nonhsm;
                                memCosting.hsm = result[0].hsm;
                                memCosting.nonhsm = result[0].nonhsm;
                            }
                            callback(null, {
                                success: 1
                            });
                            return;
                        });
                    }
                });
            }
        });
    };
    var saveAggregates = function () {
        aggOutbound = 1;
        var query = "INSERT INTO `ezb_bot_aggregates` (`botid`,`logdate`,`inbound`,`outbound`,`buttonclick`,`sms`,`email`,`chatsession`)" +
            "VALUES(?,CURDATE(),IFNULL(`inbound`,0)+?,IFNULL(`outbound`,0)+?,IFNULL(`buttonclick`,0)+?,IFNULL(`sms`,0)+?,IFNULL(`email`,0)+?,IFNULL(`chatsession`,0)+?)" +
            "ON DUPLICATE KEY UPDATE `inbound`=IFNULL(`inbound`,0)+VALUES(`inbound`),`outbound`=IFNULL(`outbound`,0)+VALUES(`outbound`),`buttonclick`=IFNULL(`buttonclick`,0)+VALUES(`buttonclick`),`sms`=IFNULL(`sms`,0)+VALUES(`sms`),`email`=IFNULL(`email`,0)+VALUES(`email`),`chatsession`=IFNULL(`chatsession`,0)+VALUES(`chatsession`)";
        var values = [botId, aggInbound, aggOutbound, aggButton, aggSms, aggEmail, aggSession];
        dbpool.query(query, values, function (err, results) {
            if (err) {
                errorLogger.error(JSON.stringify(err));
                return;
            }
        });
    };
    var logMessage = function () {
        if (strLogMessage.length > 0) {
            var type = messageObj.type.toLowerCase();
            var msgSubType = 0; //text
            var waCost = (msgType == 1) ? memCosting.hsm : memCosting.nonhsm;
            var msgCost = (waChargeCriteria <= 1) ? waCost : 0.0;
            //strLogMessage = type+" : "+strLogMessage;
            //0->text,1->hsm,2->image,3->audio,4->video,5->document,6->location
            switch (type) {
                case 'hsm':
                    msgCost = (memCosting.configured == true && memCosting.type == 0) ? (msgType == 1) ? memCosting.hsm : memCosting.text : msgCost;
                    msgSubType = 1;
                    break;
                case 'template':
                    msgCost = (memCosting.configured == true && memCosting.type == 0) ? (msgType == 1) ? memCosting.hsm : memCosting.text : msgCost;
                    msgSubType = 1;
                    break;
                case 'text':
                    msgCost = (memCosting.configured == true && memCosting.type == 0) ? memCosting.text : msgCost;
                    msgSubType = 0;
                    break;
                case 'image':
                    msgCost = (memCosting.configured == true && memCosting.type == 0) ? memCosting.image : msgCost;
                    msgSubType = 2;
                    break;
                case 'audio':
                    msgCost = (memCosting.configured == true && memCosting.type == 0) ? memCosting.audio : msgCost;
                    msgSubType = 3;
                    break;
                case 'video':
                    msgCost = (memCosting.configured == true && memCosting.type == 0) ? memCosting.video : msgCost;
                    msgSubType = 4;
                    break;
                case 'document':
                    msgCost = (memCosting.configured == true && memCosting.type == 0) ? memCosting.document : msgCost;
                    msgSubType = 5;
                    break;
                case 'location':
                    msgCost = (memCosting.configured == true && memCosting.type == 0) ? memCosting.location : msgCost;
                    msgSubType = 6;
                    break;
                default:
                    msgCost = (memCosting.configured == true && memCosting.type == 0) ? memCosting.text : msgCost;
                    msgSubType = 0;
                    break;
            }
            if (memCosting.type == 1) { //fixed costing
                var date = new Date();
                var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
                var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
                var startDate = firstDay.getFullYear() + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate() + ' 00:00:00';
                var endDate = lastDay.getFullYear() + '-' + (lastDay.getMonth() + 1) + '-' + lastDay.getDate() + ' 23:59:59';
                var paramMsgType = 0; //(msgSubType!=1)?0:1;
                var paramDirection = (msgSubType != 1) ? 1 : 0;
                var query = "SELECT `botid`,`sessid`,`loggedat` FROM `ezb_chat_logs` WHERE (`loggedat` BETWEEN ? AND ?) AND `direction`=? AND `msgtype`=? AND `sessid`=? LIMIT 1"; //USE INDEX (ind_chat_datedirtypesess)
                var values = [startDate, endDate, paramDirection, paramMsgType, sessionId];
                dbpool.query(query, values, function (err, result) {
                    if (err) {
                        errorLogger.error(JSON.stringify(err));
                    }
                    if (result != null && result.length > 0) {
                        msgCost = 0.0;
                    } else {
                        msgCost = (msgSubType != 1) ? memCosting.nonhsm : memCosting.hsm;
                    }
                    var query = 'INSERT INTO `ezb_chat_logs`(`botid`,`sessid`,`sessmobile`,`loggedat`,`direction`,`chatmsg`,`isbutton`,`parentbtn`,`msguniqueid`,`msgtype`,`msgchannel`,`msgwacharge`,`msgagentid`,`msgticketid`,`msgsubtype`) VALUES(?,?,?,NOW(),?,?,?,?,?,?,?,?,?,?,?)';
                    var values = [botId, sessionId, wanumber, 1, strLogMessage, 0, '', waMessageId, msgType, msgChannel, msgCost, chatAgentId, chatTicketId, msgSubType];
                    dbpool.query(query, values, function (err, result) {
                        if (err) {
                            errorLogger.error(JSON.stringify(err));
                        }
                    });
                });
            } else {
                if (memCosting.configured == true && memCosting.type == 0 && msgType == 0 && msgSubType == 1) {
                    msgSubType = 0;
                }
                var query = 'INSERT INTO `ezb_chat_logs`(`botid`,`sessid`,`sessmobile`,`loggedat`,`direction`,`chatmsg`,`isbutton`,`parentbtn`,`msguniqueid`,`msgtype`,`msgchannel`,`msgwacharge`,`msgagentid`,`msgticketid`,`msgsubtype`) VALUES(?,?,?,NOW(),?,?,?,?,?,?,?,?,?,?,?)';
                var values = [botId, sessionId, wanumber, 1, strLogMessage, 0, '', waMessageId, msgType, msgChannel, msgCost, chatAgentId, chatTicketId, msgSubType];
                dbpool.query(query, values, function (err, result) {
                    if (err) {
                        errorLogger.error(JSON.stringify(err));
                    }
                });
            }
        }
    };
    var sendMessage = function () {
        //console.log("send message");
        var objMsg = {};
        var type = messageObj.type.toLowerCase();
        //evaluate if paid or free
        if (!validator.isEmpty(sessionLatestLogTime + '')) {
            try {
                var startTime = moment(sessionLatestLogTime, 'YYYY-M-DD HH:mm:ss');
                var now = moment();
                var currentTime = moment(now, 'YYYY-M-DD HH:mm:ss');
                var hoursDiff = currentTime.diff(startTime, 'hours');
                hoursDiff = Math.abs(hoursDiff);
                if (hoursDiff >= 24) { //if 24 hr window expired mark message as paid
                    msgType = 1;
                }
            } catch (e) {
                errorLogger.error(e);
            }
        } else {
            msgType = 1; //first message of chat - ie no previous session
        }
        if (parseInt(msgType) == 1 && !validator.equals("hsm", type) && !validator.equals("template", type)) {
            error = true;
            errCode = 'WA011';
            errMsg = 'Cannot send a non template message outside of 24 hour window';
            res.status(200).send({
                'code': errCode,
                'status': errMsg
            });
            return;
        }
        //format waid
        if (/^\+/.test(waid) == true) {
            waid = waid.substr(1);
        }
        if (type == "hsm") {
            let params = [];
            if (typeof messageObj.message.placeholders !== 'undefined' && messageObj.message.placeholders.length > 0) {
                let len = messageObj.message.placeholders.length;
                for (let y = 0; y < len; ++y) {
                    let paramVal = messageObj.message.placeholders[y];
                    params.push({
                        "default": paramVal
                    });
                }
            }
            objMsg = {
                "to": waid,
                "type": "hsm",
                "hsm": {
                    "namespace": hsmnamespace,
                    "element_name": hsmtitle,
                    "language": {
                        "policy": "deterministic",
                        "code": (langcode !== '') ? langcode : "en"
                    },
                    "localizable_params": params
                }
            };
        } else if (type === "template") {
            objMsg = {
                "to": waid,
                "type": "template",
                "template": {
                    "namespace": hsmnamespace,
                    "language": {
                        "policy": "deterministic",
                        "code": (langcode !== '') ? langcode : "en"
                    },
                    "name": hsmtitle,
                    "components": []
                }
            };
            let component_header = {
                "type": "header",
                "parameters": [{
                    "type": temptype,
                    [temptype]: {
                        [hsmMediaType]: mediaMetaData,
                        "caption": (typeof messageObj.message.caption != 'undefined') ? messageObj.message.caption : "",
                        "filename": (typeof messageObj.message.filename != 'undefined') ? messageObj.message.filename : ""
                    }
                }]
            };
            let bodyOfTemplate = {
                "type": "body"
            };
            if (typeof messageObj.message.url !== 'undefined') {
                objMsg.template.components.push(component_header);
                strLogMessage = messageObj.message.url;
            } else {
                if (typeof messageObj.message.mediaid !== 'undefined') {
                    objMsg.template.components.push(component_header);
                    strLogMessage = messageObj.message.mediaid;
                }
            }
            let params = [];
            if (typeof messageObj.message.placeholders !== 'undefined' && messageObj.message.placeholders.length > 0) {
                let len = messageObj.message.placeholders.length;
                for (let y = 0; y < len; ++y) {
                    let paramVal = messageObj.message.placeholders[y];
                    params.push({
                        "type": "text",
                        "text": paramVal
                    });
                }
                bodyOfTemplate.parameters = params;
                objMsg.template.components.push(bodyOfTemplate);
            }
            if (typeof messageObj.message.buttons !== 'undefined') {
                if (messageObj.message.buttons.length > 0) {
                    let len = messageObj.message.buttons.length;
                    for (let y = 0; y < len; ++y) {
                        let paramVal = messageObj.message.buttons[y];
                        objMsg.template.components.push({
                            "type": "button",
                            "sub_type": paramVal.type,
                            "index": paramVal.index,
                            "parameters": paramVal.parameters
                        });
                    }
                }
            }
        } else if (type == "text") {
            objMsg = {
                "to": waid,
                "type": "text",
                "recipient_type": "individual",
                "text": {
                    "body": messageObj.message.text
                }
            };
            strLogMessage = messageObj.message.text;
        } else if (type == "audio") {
            objMsg = {
                "to": waid,
                "type": "audio",
                "recipient_type": "individual",
                "audio": {
                    "provider": {
                        "name": ""
                    }
                }
            };
            //"link": messageObj.message.url
            if (!validator.isEmpty(whatsappMediaId)) {
                objMsg.audio.id = whatsappMediaId;
                strLogMessage = "Audio By mediaId " + whatsappMediaId;
            } else {
                objMsg.audio.link = messageObj.message.url;
                strLogMessage = messageObj.message.url;
            }
        } else if (type == "video") {
            objMsg = {
                "to": waid,
                "type": "video",
                "recipient_type": "individual",
                "video": {
                    "provider": {
                        "name": ""
                    },
                    "caption": (typeof messageObj.message.caption != 'undefined') ? messageObj.message.caption : ""
                }
            };
            //"link": messageObj.message.url
            if (!validator.isEmpty(whatsappMediaId)) {
                objMsg.video.id = whatsappMediaId;
                strLogMessage = "Video By mediaId " + whatsappMediaId;
            } else {
                objMsg.video.link = messageObj.message.url;
                strLogMessage = messageObj.message.url;
            }
        } else if (type == "image") {
            objMsg = {
                "to": waid,
                "type": "image",
                "recipient_type": "individual",
                "image": {
                    "provider": {
                        "name": ""
                    },
                    "caption": (typeof messageObj.message.caption != 'undefined') ? messageObj.message.caption : ""
                }
            };
            //"link": messageObj.message.url,
            if (!validator.isEmpty(whatsappMediaId)) {
                objMsg.image.id = whatsappMediaId;
                strLogMessage = "Image by mediaId " + whatsappMediaId;
            } else {
                objMsg.image.link = messageObj.message.url;
                strLogMessage = messageObj.message.url;
            }
        } else if (type == "document") {
            objMsg = {
                "to": waid,
                "type": "document",
                "recipient_type": "individual",
                "document": {
                    "provider": {
                        "name": ""
                    },
                    "caption": (typeof messageObj.message.caption != 'undefined') ? messageObj.message.caption : ""
                }
            };
            if (!validator.isEmpty(whatsappMediaId)) {
                objMsg.document.id = whatsappMediaId;
                objMsg.document.filename = whatsappMediaFileName;
                strLogMessage = "Document by mediaId " + whatsappMediaId;
            } else {
                objMsg.document.link = messageObj.message.url;
                objMsg.document.filename = messageObj.message.filename;
                strLogMessage = messageObj.message.url;
            }
        } else if (type == "location") {
            objMsg = {
                "to": waid,
                "type": "location",
                "recipient_type": "individual",
                "location": {
                    "longitude": messageObj.message.longitude,
                    "latitude": messageObj.message.latitude,
                    "name": messageObj.message.name,
                    "address": messageObj.message.address
                }
            };
        }
        var api = '/v1/messages';
        var httpMethod = 1;
        var requestType = 1;
        var contentLength = Buffer.byteLength(JSON.stringify(objMsg));
        var apiHeaders = [{
            'headerName': 'Authorization',
            'headerVal': 'Bearer ' + authToken
        }, {
            'headerName': 'content-length',
            'headerVal': contentLength
        }];
        //console.log(instanceUrl+api);
        //console.log(objMsg);
        botUtils.callWhatsAppApi(instanceUrl, api, objMsg, httpMethod, requestType, apiHeaders).then(function (response) {
            //console.log("send response");
            //console.log(response);
            if (typeof response.messages != 'undefined') {
                //success
                waMessageId = (typeof response.messages[0].id != 'undefined') ? response.messages[0].id : '';
                logMessage();
                saveAggregates();
                messageType = (msgType == 1) ? 'TEMPLATE' : 'SESSION';
                res.status(200).send({
                    'code': 200,
                    'status': 'success',
                    'messageid': waMessageId,
                    'messagetype': messageType
                });
                errorLogger.info(JSON.stringify({
                    'botid': botId,
                    'code': 200,
                    'status': 'success',
                    'messageid': waMessageId,
                    'messagetype': messageType
                }));
                return;
            } else {
                //error
                res.status(200).send({
                    code: errCode,
                    status: errMsg
                });
                errorLogger.error(JSON.stringify({
                    botid: botId,
                    code: errCode,
                    status: errMsg
                }));
                return;
            }
        }).catch(function (err) {
            errorLogger.error(JSON.stringify({
                botid: botId,
                code: errCode,
                status: errMsg
            }));
            errorLogger.error(err);
            res.status(200).send({
                code: errCode,
                status: errMsg
            });
            return;
        });
    };
    async.waterfall([validateApiKey, selectBot, getWaSettings, validateRequest, fetchTemplate, checkMediaId, checkPrivilege, generateAuthToken, checkContact, addContact, moduleExists, chatSession, saveAttribute, getMessageCosting], function (err, result) {
        //console.log("waterfall complete");
        //console.log(result);
        if (err) {
            errorLogger.error(JSON.stringify(err));
            res.status(200).send({
                code: errCode,
                status: errMsg
            });
            errorLogger.error(JSON.stringify({
                botid: botId,
                code: errCode,
                status: errMsg
            }));
            return;
        }
        if (typeof result.success != 'undefined' && parseInt(result.success) != 1) {
            if (isDeactivatedBot) {
                error = true;
                errCode = 'WA100';
                errMsg = 'The bot you are trying to access either does not exists or is no longer maintained by its owner';
            } else {
                error = true;
            }
        }
        if (error) {
            res.status(200).send({
                code: errCode,
                status: errMsg
            });
            errorLogger.error(JSON.stringify({
                botid: botId,
                code: errCode,
                status: errMsg
            }));
            return;
        }
        sendMessage();
    });
}