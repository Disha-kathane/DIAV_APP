module.exports = (req, res) => {
    try {
        if (!req.headers.apikey) {
            return {
                code: 403,
                status: 'FAILED',
                message: 'API Key is required',
                data: {}
            };
        }
        const apiKey = req.headers.apikey;
        const userId = await userService.getUserId(apiKey);
        if (!userId) {
            return {
                code: 400,
                status: 'FAILED',
                message: 'Correct API Key is required',
                data: {}
            };
        }

        if (!(req.body.tempid && req.body.tempid.length)) {
            return {
                code: 400,
                status: 'FAILED',
                message: 'tempid cannot be empty',
                data: {}
            };
        }
        const tempIdList = req.body.tempid;
        const AccessToken = await templateService.getSystemAccessToken();
        const access_token = AccessToken[0].value;
        const tempListResponse = await templateService.getTemplateDetails(tempIdList);
        await Promise.all(tempListResponse.map(async (item, index) => {
            await deleteTemplate ;

        }));
        return{
            code: 200,
            status: 'SUCCESS',
            message: 'Templates Deleted',
        };

} catch (error) {
    console.log(error);
    //errorLogger.error(JSON.stringify(error));
    return error;
}
}
