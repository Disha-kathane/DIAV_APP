const botUtils = require('../utils/bot');
const async = require('async');

module.exports = (req, res) => {
    async.waterfall([
        function (done) {
            const query = 'SELECT * FROM `tbl_message_request_master` WHERE appisprocessed = ? limit 10;'
            var values = [0];
            const s = dbpool.query(query, values, function (err, result) {
                console.log(result);
                done(err, result);
            });
            console.log(s.sql);
        },
        function (msgResult, done) {

            msgResult.forEach((item, index) => {
                let objMsg = {};
                switch (item.messagetype) {
                    case 2: {
                        //console.log("i am here");
                    }
                        break;
                    case 0: {
                        objMsg = {
                            "to": item.mobileno,
                            "type": item.messagetype,
                            "hsm": {
                                "namespace": item.namespace,
                                "element_name": "hsm_msg",
                                "language": {
                                    "policy": "deterministic",
                                    "code": "en"
                                },

                            }
                        };
                    }
                        break;

                    default:
                        break;
                }
                var api = '/v1/messages';
                var httpMethod = 1;
                var requestType = 1;
                var contentLength = Buffer.byteLength(JSON.stringify(objMsg));
                var apiHeaders = [{
                    'headerName': 'Authorization',
                    'headerVal': 'Bearer ' + item.accesstoken
                }, {
                    'headerName': 'content-length',
                    'headerVal': contentLength
                }];

                botUtils.callWhatsAppApi(item.wabaurl, api, objMsg, httpMethod, requestType, apiHeaders).then(function (response) {
                    console.log("send response");
                    console.log(response);
                    if (typeof response.messages != 'undefined') {
                        //success
                        waMessageId = (typeof response.messages[0].id != 'undefined') ? response.messages[0].id : '';
                        done(null, {
                            code: 200,
                            status: 'SUCCESS',
                            message: waMessageId
                        });
                    } else {
                        done({
                            code: WA000,
                            status: 'FAILED',
                            message: 'Sorry unable to process request'
                        });
                        return;
                    }
                }).catch(function (err) {
                    done({
                        code: WA000,
                        status: 'FAILED',
                        message: err
                    });
                    return;
                });
            });
        }
    ], function (err, result) {
        if (err) {
            res.status(400).send({
                code: 400,
                status: 'FAILED',
                message: err
            });
        }
        else {
            res.status(200).send({
                code: 200,
                status: 'SUCCESS',
                message: result
            });
        }
    });
}