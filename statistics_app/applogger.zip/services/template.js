const wabot_db = require('../db/wabot');
var appLoggers = require('../applogger.js');
var errorLogger = appLoggers.errorLogger;
const {    
    TBL_SYSTEM_CONFIG_MASTER,  
    TBL_TEMPLATE_MASTER  
} = require('../constants/tables');
const { result } = require('lodash');

const getSystemAccessToken = async() => {
    const query = 'select value from '+TBL_SYSTEM_CONFIG_MASTER+' where paramname = ?';
    const value = ['ACCESS_TOKEN'];
    const result = await wabot_db.query(query,value);
    return result[0];
};

const getTemplateDetails = async(tempIdList) => {
    const query = 'select temptitle, head_temptype, head_mediatype, category, langcode, body_message, status, head_text_title, footer_text, placeholders, button_option, button_option_string from '+TBL_TEMPLATE_MASTER+' where tempid in (?)';
    const value = [tempIdList];
    const [ result ] = await wabot_db.query(query, value);
    return result;
};

const updateMsgResponseId = async (msgTempID, generateTempID) => {
    const query = 'update '+TBL_TEMPLATE_MASTER+'  set `waba_approval_response_id` = ? where tempid = ?; ';
    const value = [generateTempID, msgTempID];
    return wabot_db.query(query, value);    
};

const updateMsgTemplateStatus = async (statusCode, tempTitle) => {
    const query = 'update '+TBL_TEMPLATE_MASTER+'  set `status` = ? where temptitle = ?; ';
    const value = [statusCode, tempTitle];
    return wabot_db.query(query, value);    
}

const getTemplateTitles = async () => {
    const query = 'select `temptitle` from '+TBL_TEMPLATE_MASTER+' where status = 0 and waba_approval_response_id is not null';
    const [ result ] = await wabot_db.query(query);
    return result;
}

module.exports = {
    getSystemAccessToken,
    getTemplateDetails,
    updateMsgResponseId,
    updateMsgTemplateStatus,
    getTemplateTitles
}