const app = require('fastify');
const initRoutes = require('./route');

const fastify = app({
    logger: false
});

async function start () {
    try {
        // await fastify.register(fastifyExpress);
        initRoutes(fastify);
        await fastify.listen(3000);
        //require('./cron/optinLoginCron').start();
        //require('./cron/optinContactCron').start();
        //require('./cron/sendMessageCron').start();
        //require('./cron/templateStatusCron').start();
    } catch (err) {
        console.log(err);
    }
}
start();