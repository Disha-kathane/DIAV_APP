const otpInController = require('../controller/optIn');
const otpOutController = require('../controller/optOut');
const sendController = require('../controller/send');
const sendNewController = require('../controller/sendNew');
const uploadController = require('../controller/upload');
const healthController = require('../controller/health')
const messageTemplateController = require('../controller/messageTemplates')
const mediaTemplateController = require('../controller/mediaTemplates')
const DBStatsController = require('../controller/DBStats')

const userService = require('../services/users');

module.exports = (upload) => {
    const optInOpts = {
        preHandler: [
            async (req, response, next) => {
                if (!req.headers.apikey) {
                    return {
                        code: 403,
                        status: 'FAILED',
                        message: 'API Key is required',
                        data: {}
                    };
                }
                const apiKey = req.headers.apikey;
                const userId = await userService.getUserId(apiKey);
                req.userId = userId;
                if (!userId) {
                    return {
                        code: 404,
                        status: 'FAILED',
                        message: 'Correct API Key is required',
                        data: {}
                    };
                }
                // next();
            },
            upload.fields([{
                name: 'sheet',
                maxCount: 1
            }])
        ],
        handler: otpInController
    }

    const optOutOpts = {
        handler: otpOutController
    }

    const sendOpts = {
        handler: sendController
    }
    
    const sendNewOpts = {
        handler:sendNewController 
    };
 
    const uploadOpts = {
        preHandler: upload.fields([{
            name: 'sheet',
            maxCount: 1
        }]),
        handler: uploadController
    }

    const healthOpts = {
        handler: healthController
    }

    const messageTemplateOpts = {
        handler: messageTemplateController
    }
    const mediaTemplateOpts = {
        handler: mediaTemplateController
    }

    const DBStatsOpts = {
        handler: DBStatsController        
    }
  

    return (fastify, opts, done) => {
        fastify.post('/v1/optin', optInOpts);
        fastify.post('/v1/optout', optOutOpts);
        fastify.post('/v1/send', sendOpts);
        fastify.post('/v1/sendNew', sendNewOpts);
        fastify.post('/v1/upload', uploadOpts);
        fastify.post('/v1/health', healthOpts);
        fastify.post('/v1/messageTemplate', messageTemplateOpts);
        fastify.post('/v1/mediaTemplate', mediaTemplateOpts)
        fastify.post('/v1/DBStats', DBStatsOpts)
        done();
    }
}