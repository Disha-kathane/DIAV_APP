const multer = require('fastify-multer');

const userRouter = require('./users');
const wamessageRouter = require('./wamessage');

const upload = multer({
    storage: multer.diskStorage({
        destination: 'uploads/',
        filename: (req, file, cb) => {
            cb(null, `file_${req.userId}.csv`);
        }
    })
})

module.exports = (fastify) => {
    fastify.register(multer.contentParser);
    fastify.register(userRouter, { prefix: '/users' });
    fastify.register(wamessageRouter(upload), { prefix: '/wamessage' })
}