module.exports = {
    TBL_CONTACTS_MASTER: 'ezb_wa_contacts',
    TBL_SYSTEM_CONFIG_MASTER: 'ezb_system_config',
    TBL_TEMPLATE_MASTER: 'ezb_wa_templates',
}