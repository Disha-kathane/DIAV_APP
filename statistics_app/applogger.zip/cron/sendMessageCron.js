const scheduler = cron.schedule('*/30 * * * * *', async () => {
    try {
        console.log('cron job started');
        // 1. Fetch data from database that needs to be send on whatsapp
        const query = 'select `to`, `type`, `templateid`, `placeholders`, `flag` from `ezb_send_messages` where `flag` = ? limit 10;'
        var values = [0];
        const msgResult = await dbpool.query(query, values);

        if (msgResult[0].length) {
            var headers = {
                'Content-Type': 'application/json',
                'apikey':'e10f0151-fcd9-497a-b544-15f203895346'
            };

            var options = {
                // baseUrl: 'http://localhost:3000/',
                // url: 'wamessage/v1/send',
                method:'POST',
                // timeout: 3000,
                responseType: 'json',
                responseEncoding: 'utf8',
                headers: headers,
            };

            const msgPromise = msgResult[0].map(oneMessage => {
                const postData = {
                    to: oneMessage.to.toString(),
                    type: oneMessage.type,
                    message:
                        {
                            templateid: oneMessage.templateid,
                            // url: "https://pinnacle.in/assets/img/hlr/hlr.png",
                            // filename: "hlr.png",
                           // "placeholders":[]
                        },
                    gotomodule: 0
                }
                const instance = axios.create(options);
                return instance.post('http://localhost:3000/wamessage/v1/send', postData);
            })
            const msgPromiseResult = await Promise.all(msgPromise);
            console.log(msgPromiseResult);
        }
    } catch (error) {
        console.log(error);
    }
}, {
    scheduled: false
})